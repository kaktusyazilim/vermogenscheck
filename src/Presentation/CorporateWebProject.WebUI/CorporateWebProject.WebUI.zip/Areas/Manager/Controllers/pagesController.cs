﻿using CorporateWebProject.Application.Repositories;
using CorporateWebProject.Domain.Entities;
using CorporateWebProject.WebUI.Handlers.Authorization.Attributes;
using CorporateWebProject.WebUI.Handlers.Pages;
using CorporateWebProject.WebUI.Models;
using Microsoft.AspNetCore.Mvc;

namespace CorporateWebProject.WebUI.Areas.Manager.Controllers
{
    public class pagesController : BaseController<Pages>
    {
        private readonly IUserRepository _userRepository;
        private readonly IPageRepository _pageRepository;
        private readonly IModulRepository _modulRepository;
        public pagesController(IUserRepository userRepository, IPageRepository pageRepository, IModulRepository modulRepository) : base(pageRepository, AuthPage.Pages)
        {
            _userRepository = userRepository;
            _pageRepository = pageRepository;
            _modulRepository = modulRepository;
        }
        [HttpGet]
        [Auth("Read", AuthPage.Pages)]
        public IActionResult Index()
        {
            ServiceVM model = new ServiceVM(HttpContext);
            model.PageList = _pageRepository.GetList(x => x.IsDeleted == false).Data;
            return View(model);
        }

        [HttpGet]
        [Auth("Create",AuthPage.Pages)]
        public IActionResult Create()
        {
            ServiceVM model = new ServiceVM(HttpContext);
            model.ModulList=_modulRepository.GetList(x=>x.IsPassive==false && x.IsDeleted==false).Data;
            model.Page = new Pages();
            return View(model);
        }

        [HttpPost]
        [Auth("Create", AuthPage.Pages)]
        public IActionResult Create(ServiceVM model,IFormCollection fc)
        {
            var result = _pageRepository.AddAsync(model.Page);
            base.SetResponseMessage(result.Result.Success);
            return Redirect("/manager/pages");
        }

        [HttpGet]
        [Auth("Update", AuthPage.Pages)]
        public IActionResult Update(string id)
        {
            ServiceVM model = new ServiceVM(HttpContext);
            model.Page = _pageRepository.Get(x => x.ItemGuid == id).Result.Data;
            model.ModulList = _modulRepository.GetList(x => x.IsPassive == false && x.IsDeleted == false).Data;

            return View(model);
        }

        [HttpPost]
        [Auth("Update", AuthPage.Pages)]
        public IActionResult Update(ServiceVM model, IFormCollection fc)
        {
            var currentItem=_pageRepository.Get(x=>x.ItemGuid==model.Page.ItemGuid).Result.Data;
            if(currentItem!=null)
            {
               currentItem.Title=model.Page.Title;
                currentItem.Queue=model.Page.Queue;
                currentItem.Descriptions=model.Page.Descriptions;   
                currentItem.IsShow=model.Page.IsShow;
                currentItem.LangId=model.Page.LangId;
                currentItem.ModulId =model.Page.ModulId;
                currentItem.Url=model.Page.Url;
                currentItem.PageGuid = model.Page.PageGuid;
                var result= _pageRepository.UpdateAsync(currentItem);
                base.SetResponseMessage(result.Result.Success);
                return Redirect("/manager/pages");
            }
            base.SetResponseMessage(false);
            return Redirect("/manager/pages");

        }
    }
}
