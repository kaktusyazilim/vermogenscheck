﻿using CorporateWebProject.Application.Repositories;
using CorporateWebProject.Domain.Entities;
using CorporateWebProject.WebUI.Handlers.Authorization.Attributes;
using CorporateWebProject.WebUI.Handlers.Pages;
using CorporateWebProject.WebUI.Models;
using Microsoft.AspNetCore.Mvc;

namespace CorporateWebProject.WebUI.Areas.Manager.Controllers
{
    public class messagesController : BaseController<SmtpSettings>
    {
        private readonly IContactMessageRepository _contactMessageRepository;
        public messagesController(IContactMessageRepository contactMessageRepository) : base(contactMessageRepository, AuthPage.Messages)
        {
            _contactMessageRepository = contactMessageRepository;
        }

        [Auth("Read", AuthPage.Messages)]
        public IActionResult Index()
        {
            ServiceVM model = new ServiceVM(HttpContext);
            model.MessageList = _contactMessageRepository.GetList(x => x.IsDeleted == false).Data;
            return View(model);
        }

        [Auth("Delete", AuthPage.Messages)]
        public IActionResult AllDelete()
        {
            var messages = _contactMessageRepository.GetList().Data;
            foreach (var item in messages)
            {
                _contactMessageRepository.Delete(item);
            }
            base.SetResponseMessage(true);
            return Redirect("/manager/messages");
        }
    }
}
