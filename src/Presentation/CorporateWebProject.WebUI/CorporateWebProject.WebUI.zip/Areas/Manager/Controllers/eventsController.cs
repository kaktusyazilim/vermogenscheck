﻿using CorporateWebProject.Application.Repositories;
using CorporateWebProject.Application.Utilities.FriendlyUrl;
using CorporateWebProject.Domain.Entities;
using CorporateWebProject.WebUI.Handlers.Authorization.Attributes;
using CorporateWebProject.WebUI.Handlers.Pages;
using CorporateWebProject.WebUI.Models;
using Microsoft.AspNetCore.Mvc;

namespace CorporateWebProject.WebUI.Areas.Manager.Controllers
{
    public class eventsController : BaseController<Events>
    {
        private readonly IEventRepository _eventRepository;

        public eventsController(IEventRepository eventRepository) : base(eventRepository, AuthPage.SmtpSettings)
        {
            _eventRepository = eventRepository;
        }

        [Auth("Read", AuthPage.SmtpSettings)]
        public IActionResult Index()
        {
            ServiceVM model = new ServiceVM(HttpContext);
            model.EventList = _eventRepository.GetList(x => x.IsPassive == false && x.IsDeleted == false).Data;
            return View(model);
        }

        [Auth("Create", AuthPage.SmtpSettings)]
        [HttpGet]
        public IActionResult Create()
        {
            ServiceVM model = new ServiceVM(HttpContext);
            return View(model);
        }
        [Auth("Create", AuthPage.SmtpSettings)]
        [HttpPost]
        public async Task<IActionResult> Create(ServiceVM model, IFormCollection fc)
        {
            if (fc.Files["pictures"] != null)
            {
                var imageResult = base.CreateFile(fc.Files["pictures"]);
                model.Event.FilePath = imageResult.Path;
            }
            model.Event.FriendlyUrl = FriendlyUrl.FriendlyURLTitle(model.Event.Title);

            var result = await _eventRepository.AddAsync(model.Event);
            base.SetResponseMessage(result.Success);
            return Redirect("/manager/events");
        }


        [Auth("Update", AuthPage.SmtpSettings)]
        [HttpGet]
        public IActionResult Update(string id)
        {
            ServiceVM model = new ServiceVM(HttpContext);
            model.Event = _eventRepository.Get(x => x.ItemGuid == id).Result.Data;
            return View(model);
        }
        [Auth("Update", AuthPage.SmtpSettings)]
        [HttpPost]
        public async Task<IActionResult> Update(ServiceVM model, IFormCollection fc)
        {
            var currentItem = _eventRepository.Get(x => x.ItemGuid == model.Event.ItemGuid).Result.Data;
            if (currentItem != null)
            {
                if (fc.Files["pictures"] != null)
                {
                    var imageResult = base.CreateFile(fc.Files["pictures"]);
                    model.Event.FilePath = imageResult.Path;
                }
                model.Event.FriendlyUrl = FriendlyUrl.FriendlyURLTitle(model.Event.Title);
                base.Equalize(currentItem, model.Event);
                var result = await _eventRepository.UpdateAsync(currentItem);
                base.SetResponseMessage(result.Success);
                return Redirect("/manager/events");
            }
            return View();
        }
    }
}
