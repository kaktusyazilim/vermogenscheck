﻿using CorporateWebProject.Application.Repositories;
using CorporateWebProject.Domain.Entities;
using CorporateWebProject.WebUI.Handlers.Authorization.Attributes;
using CorporateWebProject.WebUI.Handlers.Pages;
using CorporateWebProject.WebUI.Models;
using Microsoft.AspNetCore.Mvc;

namespace CorporateWebProject.WebUI.Areas.Manager.Controllers
{
    public class OfficialDocumentsController : BaseController<OfficialDocuments>
    {
        private readonly IOfficialDocumentRepository _documentRepository;
        private readonly ICategoryRepository _categoryRepository;
        private readonly ISubCategoryRepository _subCategoryRepository;
        public OfficialDocumentsController(IOfficialDocumentRepository documentRepository, ICategoryRepository categoryRepository, ISubCategoryRepository subCategoryRepository) : base(documentRepository, AuthPage.OfficialDocuments)
        {
            _documentRepository = documentRepository;
            _categoryRepository = categoryRepository;
            _subCategoryRepository = subCategoryRepository;
        }
        [HttpGet]
        [Auth("Read", AuthPage.OfficialDocuments)]
        public IActionResult Index()
        {
            ServiceVM model = new ServiceVM(HttpContext);
            model.OfficialDocumentList = _documentRepository.GetList(x => x.IsDeleted == false).Data;
            return View(model);
        }

        [HttpGet]
        [Auth("Create", AuthPage.OfficialDocuments)]
        public IActionResult Create()
        {
            ServiceVM model = new ServiceVM(HttpContext);
            model.CategoryList = _categoryRepository.GetList(x => x.TypeId == model.Type.Id).Data;
            model.SubCategoryList = _subCategoryRepository.GetList(x=>x.TypeId== model.Type.Id).Data;
            return View(model);
        }

        [HttpPost]
        [Auth("Create", AuthPage.OfficialDocuments)]
        public async Task<IActionResult> Create(ServiceVM model, IFormCollection fc)
        {
            if (fc.Files["files"]!=null)
            {
                var fileResult = base.CreateFile(fc.Files["files"]);
                model.OfficialDocument.FilePath = fileResult.Path;
                var result = await _documentRepository.AddAsync(model.OfficialDocument);
                base.SetResponseMessage(result.Success);
                return Redirect("/manager/OfficialDocuments");
            }
            return View(model);
        }

        [HttpGet]
        [Auth("Update", AuthPage.OfficialDocuments)]
        public IActionResult Update(string id)
        {
            ServiceVM model = new ServiceVM(HttpContext);
            model.OfficialDocument = _documentRepository.Get(x => x.ItemGuid == id).Result.Data;
            model.CategoryList = _categoryRepository.GetList(x => x.TypeId == model.Type.Id).Data;
            model.SubCategoryList = _subCategoryRepository.GetList(x => x.TypeId == model.Type.Id).Data;
            return View(model);
        }

        [HttpPost]
        [Auth("Update", AuthPage.OfficialDocuments)]
        public async Task<IActionResult> Update(ServiceVM model, IFormCollection fc)
        {
            var currentItem=_documentRepository.Get(x=>x.ItemGuid==model.OfficialDocument.ItemGuid).Result.Data;
            if(currentItem!=null)
            {
                currentItem.SubCategoryGuid = model.OfficialDocument.SubCategoryGuid;
                currentItem.CategoryGuid=model.OfficialDocument.CategoryGuid;
                currentItem.Name= model.OfficialDocument.Name;
                currentItem.IsSubTitle=model.OfficialDocument.IsSubTitle;
                currentItem.Color = model.OfficialDocument.Color;
                if (fc.Files["files"] != null)
                {
                    var fileResult = base.CreateFile(fc.Files["files"]);
                    currentItem.FilePath = fileResult.Path;
                 
                }
                var result = await _documentRepository.UpdateAsync(currentItem);
                base.SetResponseMessage(result.Success);
                return Redirect("/manager/OfficialDocuments");
            }
            return View(model);
        }
    }
}


