﻿using CorporateWebProject.Application.Repositories;
using CorporateWebProject.WebUI.Handlers.Authorization.Attributes;
using CorporateWebProject.WebUI.Handlers.Pages;
using CorporateWebProject.WebUI.Models;
using Microsoft.AspNetCore.Mvc;

namespace CorporateWebProject.WebUI.Areas.Manager.Controllers
{
    public class typesController : BaseController<CorporateWebProject.Domain.Entities.Types>
    {
        private readonly ITypeRepository _typeRepository;
        private readonly IModulRepository _ModulRepository;
        public typesController(ITypeRepository typeRepository, IModulRepository modulRepository) : base(typeRepository, AuthPage.Type)
        {
            _typeRepository = typeRepository;
            _ModulRepository = modulRepository;
        }
        [Auth("Read", AuthPage.Type)]
        public IActionResult Index()
        {
            ServiceVM serviceVM = new ServiceVM(HttpContext);
            serviceVM.TypeList = _typeRepository.GetList(x => x.IsDeleted == false).Data;
            serviceVM.ModulList = _ModulRepository.GetList(x => x.IsDeleted == false && x.IsPassive == false).Data;

            return View(serviceVM);
        }
        [Auth("Create", AuthPage.Type)]
        [HttpGet]
        public IActionResult create()
        {
            ServiceVM model = new ServiceVM(HttpContext);
            model.ModulList=_ModulRepository.GetList(x=>x.IsDeleted==false && x.IsPassive==false).Data;
            return View(model);
        }

        [Auth("Create", AuthPage.Type)]
        [HttpPost]
        public IActionResult create(ServiceVM model)
        {
            model.Type.IsDeleted = false;
            model.Type.IsPassive = false;
            model.Type.CreateDate = DateTime.Now;
            model.Type.ModifiedDate = DateTime.Now;
            var result=_typeRepository.AddAsync(model.Type);
            base.SetResponseMessage(result.Result.Success);

            return Redirect("/manager/types");
        }

        [Auth("Update", AuthPage.Type)]
        [HttpGet]
        public IActionResult update(string id)
        {
            ServiceVM model = new ServiceVM(HttpContext);
            model.Type = _typeRepository.Get(x => x.ItemGuid == id).Result.Data;
            model.ModulList = _ModulRepository.GetList(x => x.IsDeleted == false && x.IsPassive == false).Data;

            return View(model);
        }

        [Auth("Update", AuthPage.Type)]
        [HttpPost]
        public IActionResult update(ServiceVM model, IFormCollection fc)
        {
            var currentItem = _typeRepository.Get(x => x.ItemGuid == model.Type.ItemGuid);
            if (currentItem.Result.Data != null)
            {
                if (fc.Files["pictures"]!=null)
                {
                   var image= base.CreateFile(fc.Files["pictures"]);
                    currentItem.Result.Data.Icon = image.Path;
                }
                currentItem.Result.Data.ShortDescription=model.Type.ShortDescription;
                currentItem.Result.Data.IsPage = model.Type.IsPage;
                currentItem.Result.Data.Name = model.Type.Name;
                currentItem.Result.Data.ModulId = model.Type.ModulId;
                _typeRepository.UpdateAsync(currentItem.Result.Data);
                base.SetResponseMessage(currentItem.Result.Success);
                return Redirect("/manager/types");
            }
            return View();
        }
    }
}
