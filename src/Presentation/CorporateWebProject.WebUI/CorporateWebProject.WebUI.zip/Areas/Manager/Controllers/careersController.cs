﻿using CorporateWebProject.Application.Repositories;
using CorporateWebProject.Domain.Entities;
using CorporateWebProject.WebUI.Handlers.Authorization.Attributes;
using CorporateWebProject.WebUI.Handlers.Pages;
using CorporateWebProject.WebUI.Models;
using Microsoft.AspNetCore.Mvc;

namespace CorporateWebProject.WebUI.Areas.Manager.Controllers
{
    public class careersController : BaseController<Careers>
    {
        private readonly ICareerRepository _careerRepository;
        public careersController(ICareerRepository careerRepository) : base(careerRepository, AuthPage.Careers)
        {
            _careerRepository = careerRepository;
        }
        [HttpGet]
        [Auth("Read", AuthPage.Careers)]
        public IActionResult Index()
        {
            ServiceVM model = new ServiceVM(HttpContext);
            return View(model);
        }

        [HttpGet]
        [Auth("Create", AuthPage.Careers)]
        public IActionResult Create()
        {
            ServiceVM model = new ServiceVM(HttpContext);
            return View(model);
        }

        [HttpPost]
        [Auth("Create", AuthPage.Careers)]
        public IActionResult Create(ServiceVM model, IFormCollection fc)
        {
            return View(model);
        }

        [HttpGet]
        [Auth("Update", AuthPage.Careers)]
        public IActionResult Update(string id)
        {
            ServiceVM model = new ServiceVM(HttpContext);
            return View(model);
        }

        [HttpPost]
        [Auth("Update", AuthPage.Careers)]
        public IActionResult Update(ServiceVM model, IFormCollection fc)
        {
            return View(model);
        }
    }
}
