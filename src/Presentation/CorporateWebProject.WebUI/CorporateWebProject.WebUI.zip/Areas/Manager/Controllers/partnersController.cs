﻿using Microsoft.AspNetCore.Mvc;

namespace CorporateWebProject.WebUI.Areas.Manager.Controllers
{
    public class partnersController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
