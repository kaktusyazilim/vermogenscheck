﻿using CorporateWebProject.Application.Repositories;
using CorporateWebProject.Domain.Entities;
using CorporateWebProject.WebUI.Handlers.Authorization.Attributes;
using CorporateWebProject.WebUI.Handlers.Pages;
using Microsoft.AspNetCore.Mvc;

namespace CorporateWebProject.WebUI.Areas.Manager.Controllers
{
    public class citiesController : BaseController<Cities>
    {
        private readonly ICityRepository _citiesRepository;
        private readonly IDistrictRepository _districtRepository;

        public citiesController(ICityRepository citiesRepository, IDistrictRepository districtRepository) : base(citiesRepository, AuthPage.Cities)
        {
            _citiesRepository = citiesRepository;
            _districtRepository = districtRepository;
        }

        [Auth("All", AuthPage.Cities)]
        public IActionResult GetData()
        {
            var data = _citiesRepository.GetList().Data;
            return Json(data);
        }
        [Auth("All",AuthPage.Cities)]
        public IActionResult GetDistrictData(int cityid)
        {
            var data = _districtRepository.GetList(x => x.City == cityid).Data;
            return Json(data);
        }
    }
}
