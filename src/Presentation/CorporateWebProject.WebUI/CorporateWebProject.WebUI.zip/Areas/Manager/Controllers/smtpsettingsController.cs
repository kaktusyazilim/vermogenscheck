﻿using CorporateWebProject.Application.Repositories;
using CorporateWebProject.Domain.Entities;
using CorporateWebProject.WebUI.Handlers.Authorization.Attributes;
using CorporateWebProject.WebUI.Handlers.Pages;
using CorporateWebProject.WebUI.Models;
using Microsoft.AspNetCore.Mvc;

namespace CorporateWebProject.WebUI.Areas.Manager.Controllers
{
    public class smtpsettingsController : BaseController<SmtpSettings>
    {
        private readonly ISmtpSettingRepository _smtpSettingRepository;

        public smtpsettingsController(ISmtpSettingRepository smtpSettingRepository):base(smtpSettingRepository,AuthPage.SmtpSettings)
        {
            _smtpSettingRepository = smtpSettingRepository;
        }

        [Auth("Read",AuthPage.SmtpSettings)]
        public IActionResult Index()
        {
            ServiceVM model = new ServiceVM(HttpContext);
            model.SmtpSettingList = _smtpSettingRepository.GetList(x => x.IsDeleted == false).Data;
            return View(model);
        }

        [Auth("Create", AuthPage.SmtpSettings)]
        [HttpGet]
        public IActionResult Create()
        {
            ServiceVM model = new ServiceVM(HttpContext);
            return View(model);
        }
        [Auth("Create", AuthPage.SmtpSettings)]
        [HttpPost]
        public async Task<IActionResult> Create(ServiceVM model,IFormCollection fc)
        {
            return View();
        }


        [Auth("Update", AuthPage.SmtpSettings)]
        [HttpGet]
        public IActionResult Update(string id)
        {
            ServiceVM model = new ServiceVM(HttpContext);
            model.SmtpSetting = _smtpSettingRepository.Get(x => x.ItemGuid == id).Result.Data;
            return View(model);
        }
        [Auth("Update", AuthPage.SmtpSettings)]
        [HttpPost]
        public async Task<IActionResult> Update(ServiceVM model, IFormCollection fc)
        {
            return View();
        }
    }
}
