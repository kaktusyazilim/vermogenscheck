﻿using CorporateWebProject.Application.Repositories;
using CorporateWebProject.Domain.Entities;
using CorporateWebProject.WebUI.Handlers.Authorization.Attributes;
using CorporateWebProject.WebUI.Handlers.Pages;
using CorporateWebProject.WebUI.Models;
using Microsoft.AspNetCore.Mvc;

namespace CorporateWebProject.WebUI.Areas.Manager.Controllers
{
    public class personnelsController : BaseController<Users>
    {
        private readonly IUserRepository _userRepository;
        public personnelsController(IUserRepository userRepository) : base(userRepository,AuthPage.Users)
        {
            _userRepository = userRepository;
        }

        [Auth("Read", AuthPage.Users)]
        public IActionResult Index()
        {
            ServiceVM model = new ServiceVM(HttpContext);
            model.UserList = _userRepository.GetList().Data;
            return View(model);
        }

        [Auth("Create", AuthPage.Users)]
        [HttpGet]
        public IActionResult Create()
        {
            ServiceVM model = new ServiceVM(HttpContext);
            return View(model);
        }
        [Auth("Create", AuthPage.Users)]
        [HttpPost]
        public async Task<IActionResult> Create(ServiceVM model, IFormCollection fc)
        {
            return View();
        }


        [Auth("Update", AuthPage.Users)]
        [HttpGet]
        public IActionResult Update(string id)
        {
            ServiceVM model = new ServiceVM(HttpContext);
            return View(model);
        }
        [Auth("Update", AuthPage.Users)]
        [HttpPost]
        public async Task<IActionResult> Update(ServiceVM model, IFormCollection fc)
        {
            return View();
        }
    }
}
