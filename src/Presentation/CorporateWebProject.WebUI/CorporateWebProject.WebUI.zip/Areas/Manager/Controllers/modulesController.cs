﻿using CorporateWebProject.Application.Parameters;
using CorporateWebProject.Application.Repositories;
using CorporateWebProject.Application.Utilities.FriendlyUrl;
using CorporateWebProject.Domain.Common;
using CorporateWebProject.Domain.Entities;
using CorporateWebProject.Persistence.Repositories;
using CorporateWebProject.WebUI.Handlers.Authorization;
using CorporateWebProject.WebUI.Handlers.Authorization.Attributes;
using CorporateWebProject.WebUI.Handlers.Pages;
using CorporateWebProject.WebUI.Models;
using Microsoft.AspNetCore.Mvc;
using NuGet.Protocol.Core.Types;

namespace CorporateWebProject.WebUI.Areas.Manager.Controllers
{
    [Area("manager")]
    public class ModulesController : BaseController<Modules>
    {
        private readonly IModulRepository _ModulRepository;
        private readonly ILanguageRepository _LanguageRepository;
        private readonly IPageRepository _PageRepository;
        public ModulesController(IModulRepository modulRepository, ILanguageRepository languageRepository, IPageRepository pageRepository) : base(modulRepository, AuthPage.Modules)
        {

            _ModulRepository = modulRepository;
            _LanguageRepository = languageRepository;
            _PageRepository = pageRepository;
        }

        [Auth(AuthTypes.Read, AuthPage.Modules)]
        [HttpGet]
        public IActionResult Index()
        {
            ServiceVM model = new ServiceVM(HttpContext);
            model.ModulList = _ModulRepository.GetList(x => x.IsDeleted == false).Data;
            return View(model);
        }

        [Auth(AuthTypes.Create, AuthPage.Modules)]
        [HttpGet]
        public IActionResult create()
        {
            ServiceVM model = new ServiceVM(HttpContext);
            model.LanguageList = _LanguageRepository.GetList(x => x.IsPassive == false && x.IsDeleted == false).Data;
            return View(model);
        }

        [Auth(AuthTypes.Create, AuthPage.Modules)]
        [HttpPost]
        public async Task<IActionResult> create(ServiceVM model)
        {
            model.Modul.ItemGuid = model.Modul.Title.ToUpper().Replace(" ", "");
            var result = _ModulRepository.AddAsync(model.Modul);

            if (result.Result.Success == true)
            {
                var isPage = _PageRepository.GetList(x => x.ModulId == result.Result.Data.Id).Data;
                if (!(isPage != null && isPage.Count() != 0))
                {
                    var pageResult = await _PageRepository.AddAsync(new Pages()
                    {
                        Descriptions = "",
                        IsShow = true,
                        LangId = result.Result.Data.LangId,
                        PageGuid = FriendlyUrl.FriendlyURLTitle(model.Modul.Title).Length>20? FriendlyUrl.FriendlyURLTitle(model.Modul.Title).Substring(0,20): FriendlyUrl.FriendlyURLTitle(model.Modul.Title),
                        ModulId = result.Result.Data.Id,
                        Title = "Liste",
                        Url = "index",
                        Icon = "",


                    });
                    base.SetResponseMessage(result.Result.Success);
                    return Redirect("/manager/modules");

                }
            }
            base.SetResponseMessage(false);

            return Redirect("/manager/modules");
        }

        [Auth(AuthTypes.Update, AuthPage.Modules)]
        [HttpGet]
        public IActionResult update(int id)
        {
            ServiceVM model = new ServiceVM(HttpContext);
            model.LanguageList = _LanguageRepository.GetList(x => x.IsPassive == false && x.IsDeleted == false).Data;
            model.Modul = _ModulRepository.Get(x => x.Id == id).Result.Data;
            return View(model);
        }

        [Auth(AuthTypes.Update, AuthPage.Modules)]
        [HttpPost]
        public async Task<IActionResult> update(ServiceVM model)
        {
            var currentItem = _ModulRepository.Get(x =>  x.Id == model.Modul.Id).Result.Data;
            var queues = _ModulRepository.GetList(x => x.Id!=currentItem.Id && x.IsPassive == false && x.IsDeleted == false & x.Queue >= model.Modul.Queue).Data.OrderBy(x=>x.Queue).ToList();
            int arttir = 1;
            for (int i = 0; i < queues.Count(); i++)
            {
                queues[i].Queue = model.Modul.Queue + arttir;
                var updateResult = await _ModulRepository.UpdateAsync(queues[i]);
               
                arttir++;
            }
            currentItem.Title = model.Modul.Title;
            currentItem.Queue = model.Modul.Queue;
            currentItem.ModifiedDate = DateTime.Now;
            currentItem.LangId = model.Modul.LangId;
            currentItem.Url = model.Modul.Url;
            currentItem.IsShow = model.Modul.IsShow;
            var result = await _ModulRepository.UpdateAsync(currentItem);
            base.SetResponseMessage(result.Success);
            return Redirect("/manager/modules");
        }

    }
}
