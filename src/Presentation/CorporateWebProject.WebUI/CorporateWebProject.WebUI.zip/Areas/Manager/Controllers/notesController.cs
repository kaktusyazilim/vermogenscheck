﻿using CorporateWebProject.Application.Repositories;
using CorporateWebProject.Domain.Entities;
using CorporateWebProject.WebUI.Handlers.Authorization.Attributes;
using CorporateWebProject.WebUI.Handlers.Pages;
using CorporateWebProject.WebUI.Models;
using Microsoft.AspNetCore.Mvc;

namespace CorporateWebProject.WebUI.Areas.Manager.Controllers
{
    public class notesController : BaseController<Notes>
    {
        private readonly INoteRepository _noteRepository;
        public notesController(INoteRepository noteRepository) : base(noteRepository, AuthPage.Notes)
        {
            _noteRepository = noteRepository;
        }

        [HttpGet]
        [Auth("Read", AuthPage.Notes)]

        public IActionResult Get(string id)
        {
            var data = _noteRepository.Get(x => x.ItemGuid == id).Result;
            return Json(data);
        }
        [HttpGet]
        [Auth("Read", AuthPage.Notes)]
        public IActionResult GetList()
        {
            ServiceVM model = new ServiceVM();
            model.FillData(HttpContext);
            var data = _noteRepository.GetList(x => x.IsPassive == false && x.IsDeleted == false && x.UserGuid == model.CurrentUser.ItemGuid);
            return Json(data.Data.OrderByDescending(x=>x.CreateDate).ToList());
        }
        [HttpPost]
        [Auth("Create", AuthPage.Notes)]
        public async Task<IActionResult> Create(ServiceVM model,IFormCollection fc)
        {
            model.FillData(HttpContext);
            model.Note.UserGuid = model.CurrentUser.ItemGuid;
            if (fc["noteid"].ToString()!="")
            {
                var currentItem=  _noteRepository.Get(x => x.ItemGuid == fc["noteid"].ToString()).Result.Data;
                currentItem.Title=model.Note.Title;
                currentItem.Description= model.Note.Description;
                var result = await _noteRepository.UpdateAsync(currentItem);
                base.SetResponseMessage(result.Success);
                return Json(result);
            }
            else
            {
                var result = await _noteRepository.AddAsync(model.Note);
                base.SetResponseMessage(result.Success);
                return Json(result);
            }
          
        }
        [HttpPost]
        [Auth("Update", AuthPage.Notes)]
        public async Task<IActionResult> Update(ServiceVM model)
        {
            var result = await _noteRepository.UpdateAsync(model.Note);
            base.SetResponseMessage(result.Success);
            return Json(result);
        }
    }
}
