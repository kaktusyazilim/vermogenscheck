﻿using CorporateWebProject.Application.Repositories;
using CorporateWebProject.Application.Utilities.FriendlyUrl;
using CorporateWebProject.Domain.Entities;
using CorporateWebProject.WebUI.Handlers.Authorization.Attributes;
using CorporateWebProject.WebUI.Handlers.Pages;
using CorporateWebProject.WebUI.Models;
using Microsoft.AspNetCore.Mvc;

namespace CorporateWebProject.WebUI.Areas.Manager.Controllers
{
    [Area("manager")]
    public class documentsController : BaseController<Documents>
    {
        private readonly IDocumentRepository _documentRepository;
        private readonly ICompanyRepository _companyRepository;
        private readonly IFolderRepository _folderRepository;

        public documentsController(IDocumentRepository documentRepository, ICompanyRepository companyRepository, IFolderRepository folderRepository) : base(documentRepository, AuthPage.Documents)
        {
            _documentRepository = documentRepository;
            _companyRepository = companyRepository;
            _folderRepository = folderRepository;
        }
        [HttpGet]
        [Auth("Read", AuthPage.Documents)]
        public IActionResult Index()
        {
            ServiceVM model = new ServiceVM(HttpContext);
            model.DocumentList = _documentRepository.GetList(x => x.IsDeleted == false).Data;
            model.FolderList = _folderRepository.GetList(x=>x.IsDeleted==false && x.TopGuid=="").Data;
            model.CompanyList= _companyRepository.GetList().Data;
            model.FolderPermissionList = new List<FolderPermissions>();
            model.CompanyList.ForEach(x =>
            {
                model.FolderPermissionList.Add(new FolderPermissions()
                {
                    CompanyGuid = x.ItemGuid,

                });
            });
            return View(model);
        }
        [HttpGet]
        [Auth("Read", AuthPage.Documents)]
        public IActionResult document(string id)
        {
            ServiceVM model = new ServiceVM(HttpContext);
            model.Folder = _folderRepository.Get(x => x.ItemGuid == id ).Result.Data;
            model.DocumentList = _documentRepository.GetList(x =>x.FolderGuid==model.Folder.ItemGuid &&  x.IsDeleted == false).Data;
            model.Company = _companyRepository.Get(x => x.ItemGuid == model.Folder.CompanyGuid).Result.Data;
            model.FolderList = _folderRepository.GetList(x=> x.TopGuid == id && x.IsDeleted==false).Data;
            model.SubFolderList = _folderRepository.GetList(x => x.TopGuid == model.Folder.ItemGuid && x.IsDeleted==false).Data;
            model.SubFolder = _folderRepository.Get(x => x.ItemGuid == model.Folder.TopGuid).Result.Data;
            return View(model);
        }

        [HttpGet]
        [Auth("Create", AuthPage.Documents)]
        public IActionResult Create()
        {
            ServiceVM model = new ServiceVM(HttpContext);
            return View(model);
        }

        [HttpPost]
        [Auth("Create", AuthPage.Documents)]
        public IActionResult Create(ServiceVM model, IFormCollection fc)
        {
            return View(model);
        }
        [HttpPost]
        [Auth("Create", AuthPage.Documents)]
        public IActionResult CreateFolder(ServiceVM model, IFormCollection fc)
        {
            string folderName = FriendlyUrl.FriendlyURLTitle(fc["FileName"]);

            // Klasörün oluşturulacağı yol
            string path = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "uploads", folderName);

            // Klasör yoksa oluşturulur
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }
            return Redirect("/manager/documents");
        }
        [HttpGet]
        [Auth("Update", AuthPage.Documents)]
        public IActionResult Update(string id)
        {
            ServiceVM model = new ServiceVM(HttpContext);
            return View(model);
        }

        [HttpPost]
        [Auth("Update", AuthPage.Documents)]
        public IActionResult Update(ServiceVM model, IFormCollection fc)
        {
            return View(model);
        }
    }
}