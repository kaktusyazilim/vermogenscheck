﻿using Aspose.Imaging;
using CorporateWebProject.Application.Repositories;
using CorporateWebProject.Application.Utilities.WebSettings;
using CorporateWebProject.Domain.Entities;
using CorporateWebProject.WebUI.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using System.Text;

namespace CorporateWebProject.WebUI.Controllers
{
    public class mainController : Controller
    {
        private readonly ITypeRepository _typeRepository;
        private readonly ICategoryRepository _categoryRepository;
        private readonly ISubCategoryRepository _subCategoryRepository;
        private readonly ICounterRepository _counterRepository;
        private readonly ISliderRepository _sliderRepository;
        private readonly ICompanyRepository _companyRepository;
        private readonly IBlogRepository _blogRepository;
        private readonly ILanguageRepository _languageRepository;
        private readonly IEventRepository _eventRepository;
        private readonly ICommentRepository _commentRepository;
        private readonly ILogger<mainController> _logger;
        private readonly IMemoryCache _cache;

        public mainController(ITypeRepository typeRepository, ICategoryRepository categoryRepository, ISubCategoryRepository subCategoryRepository, ICounterRepository counterRepository, ISliderRepository sliderRepository, ICompanyRepository companyRepository,  IBlogRepository blogRepository, ILanguageRepository languageRepository, IEventRepository eventRepository,  ICommentRepository commentRepository,  ILogger<mainController> logger, IMemoryCache cache)
        {
            _typeRepository = typeRepository;
            _categoryRepository = categoryRepository;
            _subCategoryRepository = subCategoryRepository;
            _counterRepository = counterRepository;
            _sliderRepository = sliderRepository;
            _companyRepository = companyRepository;
            _blogRepository = blogRepository;
            _languageRepository = languageRepository;
            _eventRepository = eventRepository;
            _commentRepository = commentRepository;
            _logger = logger;
            _cache = cache;
        }


        [HttpGet]
        public async Task<IActionResult> Index()
        {
           
            ServiceVM model = new ServiceVM(HttpContext);
            model.CategoryList = (await _categoryRepository.GetListAsync(x => x.LangId == model.CurrentLanguage.Id && x.IsPassive == false && x.IsDeleted == false)).Data;
            model.SubCategoryList = (await _subCategoryRepository.GetListAsync(x => x.LangId == model.CurrentLanguage.Id && x.IsPassive == false && x.IsDeleted == false)).Data;
            model.CounterList = (await _counterRepository.GetListAsync(x => x.LangId == model.CurrentLanguage.Id && x.IsPassive == false && x.IsDeleted == false)).Data.OrderBy(x => x.Queue).ToList();
            model.SliderList = (await _sliderRepository.GetListAsync(x => x.LangId == model.CurrentLanguage.Id && x.IsPassive == false && x.IsDeleted == false && x.LangId == model.CurrentLanguage.Id)).Data.OrderBy(x => x.Queue).ToList();
            model.CompanyList = (await _companyRepository.GetListAsync(x => x.LangId == model.CurrentLanguage.Id && x.IsTopCompany == true && x.IsPassive == false && x.IsDeleted == false)).Data;
            model.BlogList = (await _blogRepository.GetListAsync(x => x.LangId == model.CurrentLanguage.Id && x.IsPassive == false && x.IsDeleted == false)).Data;
            model.EventList = (await _eventRepository.GetListAsync(x => x.IsPassive == false && x.IsDeleted == false)).Data;
          
            model.CommentList = (await _commentRepository.GetListAsync(x => x.IsPassive == false && x.IsDeleted == false)).Data.OrderBy(x => x.Queue).ToList();
            return View(model);
        }

        [HttpGet]
        public IActionResult SetLanguage(string culture, string returnUrl)
        {

            var language = _languageRepository.Get(x => x.Code == culture).Result.Data;
            if (language != null)
            {
                Response.Cookies.Delete("Language");
                CookieOptions cookie = new CookieOptions();
                cookie.Expires = DateTime.Now.AddYears(1);
                string key = "Language";
                string value = language.Code;
                Response.Cookies.Append(key, value, cookie);
            }
            return Redirect(returnUrl);


        }

        [HttpGet]
        [Route("gizlilik-politikasi")]
        public async Task<IActionResult> gizlilik()
        {
            ServiceVM model = new ServiceVM(HttpContext);
            model.CategoryList = (await _categoryRepository.GetListAsync(x => x.IsPassive == false && x.IsDeleted == false)).Data;
            model.SubCategoryList = (await _subCategoryRepository.GetListAsync(x => x.IsPassive == false && x.IsDeleted == false)).Data;
            model.BlogList = (await _blogRepository.GetListAsync(x => x.IsPassive == false && x.IsDeleted == false)).Data;

            return View(model);
        }

        [HttpGet]
        [Route("cerez-politikasi")]
        public async Task<IActionResult> cerez()
        {
            ServiceVM model = new ServiceVM(HttpContext);
            model.CategoryList = (await _categoryRepository.GetListAsync(x => x.IsPassive == false && x.IsDeleted == false)).Data;
            model.SubCategoryList = (await _subCategoryRepository.GetListAsync(x => x.IsPassive == false && x.IsDeleted == false)).Data;
            model.BlogList = (await _blogRepository.GetListAsync(x => x.IsPassive == false && x.IsDeleted == false)).Data;
            return View(model);
        }


        [HttpGet]
        [Route("nilay-arslan")]
        [Route("elif-ergul")]
        [Route("berivan-bektas")]
        [Route("samet-kucuk")]
        public async Task<IActionResult> kartvizit()
        {
            ServiceVM model = new ServiceVM(HttpContext);
            model.CategoryList = (await _categoryRepository.GetListAsync(x => x.IsPassive == false && x.IsDeleted == false)).Data;
            model.SubCategoryList = (await _subCategoryRepository.GetListAsync(x => x.IsPassive == false && x.IsDeleted == false)).Data;
            model.BlogList = (await _blogRepository.GetListAsync(x => x.IsPassive == false && x.IsDeleted == false)).Data;
            return View(model);
        }


        [Route("/sitemap.xml")]
        public async Task<IActionResult> Sitemap()
        {
            string baseUrl = $"{Request.Scheme}://{Request.Host}{Request.PathBase}";
            string segment = "blog";
            string contentType = "application/xml";

            string cacheKey = "sitemap.xml";

            // For showing in browser (Without download)
            var cd = new System.Net.Mime.ContentDisposition
            {
                FileName = cacheKey,
                Inline = true,
            };
            Response.Headers.Append("Content-Disposition", cd.ToString());

            // Cache
            var bytes = _cache.Get<byte[]>(cacheKey);
            if (bytes != null)
                return File(bytes, contentType);

            var blogs = (await _blogRepository.GetListAsync(x => x.IsPassive == false && x.IsDeleted == false)).Data;

            var sb = new StringBuilder();
            sb.AppendLine($"<?xml version=\"1.0\" encoding=\"utf-8\"?>");
            sb.AppendLine($"<urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\"");
            sb.AppendLine($"   xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"");
            sb.AppendLine($"   xsi:schemaLocation=\"http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd\">");

            sb.AppendLine($"    <url>");
            sb.AppendLine($"        <loc>{baseUrl}/</loc>");
            sb.AppendLine($"        <lastmod>{DateTime.Now.ToString("yyyy-MM-dd")}</lastmod>");
            sb.AppendLine($"        <changefreq>daily</changefreq>");
            sb.AppendLine($"        <priority>0.8</priority>");
            sb.AppendLine($"    </url>");

            sb.AppendLine($"    <url>");
            sb.AppendLine($"        <loc>{baseUrl}/hakkimizda</loc>");
            sb.AppendLine($"        <lastmod>{DateTime.Now.ToString("yyyy-MM-dd")}</lastmod>");
            sb.AppendLine($"        <changefreq>daily</changefreq>");
            sb.AppendLine($"        <priority>0.8</priority>");
            sb.AppendLine($"    </url>");


            sb.AppendLine($"    <url>");
            sb.AppendLine($"        <loc>{baseUrl}/subeler</loc>");
            sb.AppendLine($"        <lastmod>{DateTime.Now.ToString("yyyy-MM-dd")}</lastmod>");
            sb.AppendLine($"        <changefreq>daily</changefreq>");
            sb.AppendLine($"        <priority>0.8</priority>");
            sb.AppendLine($"    </url>");

            sb.AppendLine($"    <url>");
            sb.AppendLine($"        <loc>{baseUrl}/hizmetler</loc>");
            sb.AppendLine($"        <lastmod>{DateTime.Now.ToString("yyyy-MM-dd")}</lastmod>");
            sb.AppendLine($"        <changefreq>daily</changefreq>");
            sb.AppendLine($"        <priority>0.8</priority>");
            sb.AppendLine($"    </url>");

            sb.AppendLine($"    <url>");
            sb.AppendLine($"        <loc>{baseUrl}/blog</loc>");
            sb.AppendLine($"        <lastmod>{DateTime.Now.ToString("yyyy-MM-dd")}</lastmod>");
            sb.AppendLine($"        <changefreq>daily</changefreq>");
            sb.AppendLine($"        <priority>0.8</priority>");
            sb.AppendLine($"    </url>");

            sb.AppendLine($"    <url>");
            sb.AppendLine($"        <loc>{baseUrl}/iletisim</loc>");
            sb.AppendLine($"        <lastmod>{DateTime.Now.ToString("yyyy-MM-dd")}</lastmod>");
            sb.AppendLine($"        <changefreq>daily</changefreq>");
            sb.AppendLine($"        <priority>0.8</priority>");
            sb.AppendLine($"    </url>");

          

            foreach (var m in (await _blogRepository.GetListAsync(x => x.IsPassive == false && x.IsDeleted == false)).Data)
            {
                sb.AppendLine($"    <url>");
                sb.AppendLine($"        <loc>{baseUrl}/blog/{m.FriendlyUrl}</loc>");
                sb.AppendLine($"        <lastmod>{m.CreateDate.ToString("yyyy-MM-dd")}</lastmod>");
                sb.AppendLine($"        <changefreq>daily</changefreq>");
                sb.AppendLine($"        <priority>0.8</priority>");
                sb.AppendLine($"    </url>");
            }

            foreach(var m in (await _categoryRepository.GetList(x => x.TypeId == 20 && x.IsPassive == false && x.IsDeleted == false)).Data.OrderBy(x => x.Queue).ToList())
            {
                sb.AppendLine($"    <url>");
                sb.AppendLine($"        <loc>{baseUrl}/hizmetler/{m.FriendlyUrl}</loc>");
                sb.AppendLine($"        <lastmod>{m.CreateDate.ToString("yyyy-MM-dd")}</lastmod>");
                sb.AppendLine($"        <changefreq>daily</changefreq>");
                sb.AppendLine($"        <priority>0.8</priority>");
                sb.AppendLine($"    </url>");
            }


            sb.AppendLine($"</urlset>");

            bytes = Encoding.UTF8.GetBytes(sb.ToString());

            _cache.Set(cacheKey, bytes, TimeSpan.FromHours(24));
            return File(bytes, contentType);

        }
        [Route("/robots.txt")]
        public ContentResult RobotsTxt()
        {
            var sb = new StringBuilder();
            sb.AppendLine("User-agent: *")
                .AppendLine("Allow: /")
                .AppendLine("Disallow:")
                .AppendLine("Disallow: /cgi-bin/")
                .Append("sitemap: ")
                .Append(this.Request.Scheme)
                .Append("://")
                .Append(this.Request.Host)
                .AppendLine("/sitemap.xml");

            return this.Content(sb.ToString(), "text/plain", Encoding.UTF8);
        }
    }
}
