﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CorporateWebProject.Infrastructure.Payment.Enums
{
    public enum ItemType
    {
        PHYSICAL = 0,
        VIRTUAL = 1
    }
}
