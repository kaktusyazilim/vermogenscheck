﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using CorporateWebProject.Application.Exceptions;
using CorporateWebProject.Application.Repositories;
using CorporateWebProject.Application.Utilities.ExceptionHelpers;
using CorporateWebProject.Application.Wrappers.Abstract;
using CorporateWebProject.Application.Wrappers.Concrete;
using CorporateWebProject.Domain.Common;
using CorporateWebProject.Persistence.Contexs;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using Microsoft.Extensions.Caching.Memory;
using CorporateWebProject.Application.Parameters;

namespace CorporateWebProject.Persistence.Repositories
{
    public class BaseRepository<T> : IBaseRepository<T> where T : EntityBase
    {
        private readonly ProjectContext _db;
        private readonly IMemoryCache _memoryCache;

        public BaseRepository(ProjectContext db, IMemoryCache memoryCache)
        {
            _db = db;
            _memoryCache = memoryCache;
        }

        public DbSet<T> Table => _db.Set<T>();

        public async Task<IDataResult<List<T>>> GetListAsync(Expression<Func<T, bool>>? filter = null, bool tracking = false)
        {
            var cacheKey = typeof(T).Name + "_list";
            if (_memoryCache.TryGetValue(cacheKey, out List<T> cachedList))
            {
                return new SuccessDataResult<List<T>>(cachedList);
            }

            try
            {
                var query = Table.AsQueryable();
                if (!tracking) query = query.AsNoTracking();

                var result = filter != null ? await query.Where(filter).ToListAsync() : await query.ToListAsync();
                _memoryCache.Set(cacheKey, result, TimeSpan.FromMinutes(10)); // Cache sonucu 10 dakika sakla

                return new SuccessDataResult<List<T>>(result, ResponseMessage.SuccessMessage);
            }
            catch (Exception ex)
            {
                return new ErrorDataResult<List<T>>(ExceptionHelper.GetErrorMessage(ex));
            }
        }

        public async Task<IDataResult<T>> Get(Expression<Func<T, bool>> filter, bool tracking = false)
        {
            try
            {
                var query = Table.AsQueryable();
                if (!tracking) query = query.AsNoTracking();

                var result = await query.FirstOrDefaultAsync(filter);
                if (result != null)
                {
                    return new SuccessDataResult<T>(result, ResponseMessage.SuccessMessage);
                }
                else
                {
                    return new ErrorDataResult<T>(ResponseMessage.NotFoundObject);
                }
            }
            catch (Exception ex)
            {
                return new ErrorDataResult<T>(ExceptionHelper.GetErrorMessage(ex));
            }
        }

        public async Task<IDataResult<T>> AddAsync(T entity)
        {
            var stopwatch = Stopwatch.StartNew();
            try
            {
                EntityEntry<T> state = await Table.AddAsync(entity);
                await SaveAsync();
                stopwatch.Stop();
                Debug.WriteLine($"AddAsync took {stopwatch.ElapsedMilliseconds}ms");

                return new SuccessDataResult<T>(entity, ResponseMessage.SuccessMessage);
            }
            catch (Exception ex)
            {
                return new ErrorDataResult<T>(ExceptionHelper.GetErrorMessage(ex));
            }
        }

        public async Task<IResult> UpdateAsync(T entity)
        {
            try
            {
                var entry = _db.Entry(entity);
                if (entry.State == EntityState.Detached)
                {
                    Table.Attach(entity);
                }
                entry.State = EntityState.Modified;
                await SaveAsync();

                return new SuccessDataResult<T>(entity, ResponseMessage.SuccessMessage);
            }
            catch (Exception ex)
            {
                return new ErrorDataResult<T>(ExceptionHelper.GetErrorMessage(ex));
            }
        }

        public async Task<IResult> Delete(T entity)
        {
            try
            {
                Table.Remove(entity);
                await SaveAsync();
                return new SuccessDataResult<T>(entity, ResponseMessage.SuccessMessage);
            }
            catch (Exception ex)
            {
                return new ErrorDataResult<T>(ExceptionHelper.GetErrorMessage(ex));
            }
        }

        private async Task<int> SaveAsync()
        {
            return await _db.SaveChangesAsync();
        }
    }
}
