﻿using Microsoft.EntityFrameworkCore.Storage;
using CorporateWebProject.Application.Repositories;
using CorporateWebProject.Application.UnitOfWork;
using CorporateWebProject.Persistence.Contexs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CorporateWebProject.Persistence.UnitOfWorks
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly ProjectContext _context;


        public UnitOfWork(ProjectContext context)
        {
            _context = context;
        }
        public async Task<IDbContextTransaction> BeginTransactionAsync() => await _context.Database.BeginTransactionAsync();
        public async ValueTask DisposeAsync() { }
    }
}
