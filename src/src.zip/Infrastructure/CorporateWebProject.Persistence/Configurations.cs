﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CorporateWebProject.Persistence
{
    static class Configurations
    {
        static public string ConnectionString
        {
            get
            {
                //ConfigurationManager configurationManager = new();
                //configurationManager.SetBasePath(Path.Combine(Directory.GetCurrentDirectory(), "../CorporateWebProject.WebAPI"));
                //configurationManager.AddJsonFile("appsettings.json");
                //return configurationManager.GetConnectionString("Mssql")!;
                return "server=mssql.kaktusdns.com;database=UplifeAcademyDB;uid=kaktusadmin;pwd=Ynyhqmdek35;Trusted_Connection=True;TrustServerCertificate=True;;Integrated Security=False;";

                return "server=mssql.kaktusyazilim.com;database=UplifeAcademyDB;uid=kaktusadmin;pwd=ynyhqmdek35;Trusted_Connection=True;TrustServerCertificate=True;;Integrated Security=False;";
            }
        }
    }
}
