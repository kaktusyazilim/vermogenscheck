﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CorporateWebProject.Application.Enums
{
   public enum InvoiceStatu
    {
        HataliIslem=1,
        BasariliIslem=2,
        Odenmedi=3,
        Odendi=4,
    }
}
