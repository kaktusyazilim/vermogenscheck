﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CorporateWebProject.Application.Enums
{
    public static class ItemTypes
    {
        public static int CountryId { get { return 92; } }
        public static string CountryGuid { get { return "1b9f6187d510484482f"; } }
    }
}
