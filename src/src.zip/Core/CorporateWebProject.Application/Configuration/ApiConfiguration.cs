﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CorporateWebProject.Application.Configuration
{
    public static class ApiConfiguration
    {
        public static string path { get { return "http://webadmin.e-akillitahta.com/"; ; } }
        public static string clientId { get { return "T51Rlz1da-_t8GiXkW7kIxXg9eWyjHeKOw5lEBmUL4Q"; } }
        public static string clientSecret { get { return "i3Lo56tFIMGLhD4NTTcghwMdZ5DtbYleSR2CAO0m67U"; } }
    }
}
