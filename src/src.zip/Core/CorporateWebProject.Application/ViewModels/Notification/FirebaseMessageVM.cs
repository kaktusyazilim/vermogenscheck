﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CorporateWebProject.Application.ViewModels.Notification
{
    public class FirebaseMessageVM
    {
        public string message_id { get; set; } = string.Empty;
    }
}
