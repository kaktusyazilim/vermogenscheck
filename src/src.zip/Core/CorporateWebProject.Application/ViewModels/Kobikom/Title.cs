﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CorporateWebProject.Infrastructure.SmsService.Entitiy.Kobikom
{
    public class Title
    {
        public string id { get; set; } = string.Empty;
        public string sender_id { get; set; } = string.Empty;
        public string status { get; set; } = string.Empty;
        public string created_at { get; set; } = string.Empty;
        public string updated_at { get; set; } = string.Empty;
    }
}
