﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CorporateWebProject.Application.Dto.Sms
{
    public class KobikomJsonDTO
    {
        public string ApiKey { get; set; } = string.Empty;
    }
}
